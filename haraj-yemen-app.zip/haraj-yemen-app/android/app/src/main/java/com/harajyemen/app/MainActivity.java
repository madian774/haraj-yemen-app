package com.harajyemen.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
