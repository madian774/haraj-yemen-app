/* ============================================================
   حراج اليمن - JavaScript Application
   ============================================================ */

// Category icons mapping
const categoryIcons = {
    'all': '🏪',
    'cars': '🚗',
    'real-estate': '🏠',
    'furniture': '🛋️',
    'electronics': '📱',
    'jobs': '💼'
};

// Category names
const categoryNames = {
    'all': 'الكل',
    'cars': 'سيارات',
    'real-estate': 'عقارات',
    'furniture': 'أثاث',
    'electronics': 'أجهزة كهربائية',
    'jobs': 'وظائف'
};

// Sample Data - Mock ads for demonstration
const sampleAds = [
    // Cars
    {
        id: '1',
        title: 'تويوتا كامري 2023 - فل كامل',
        category: 'cars',
        categoryName: 'سيارات',
        price: 45000000,
        currency: 'YER',
        negotiable: true,
        location: 'صنعاء',
        city: 'صنعاء',
        images: [],
        status: 'active',
        viewsCount: 245,
        specifications: {
            brand: 'تويوتا',
            model: 'كامري',
            year: 2023,
            color: 'أبيض',
            condition: 'new',
            kilometers: 0
        },
        trader: {
            id: 't1',
            name: 'أحمد محمد العيسي',
            phone: '777123456',
            isVerified: true,
            rating: 4.8,
            ratingCount: 45,
            city: 'صنعاء'
        }
    },
    {
        id: '2',
        title: 'هيونداي سوناتا 2022 - بانوراما',
        category: 'cars',
        categoryName: 'سيارات',
        price: 32000000,
        currency: 'YER',
        negotiable: true,
        location: 'عدن',
        city: 'عدن',
        images: [],
        status: 'active',
        viewsCount: 189,
        specifications: {
            brand: 'هيونداي',
            model: 'سوناتا',
            year: 2022,
            color: 'أسود',
            condition: 'used',
            kilometers: 45000
        },
        trader: {
            id: 't2',
            name: 'خالد الحميدي',
            phone: '771234567',
            isVerified: true,
            rating: 4.5,
            ratingCount: 32,
            city: 'عدن'
        }
    },
    {
        id: '3',
        title: 'كيا سيلتوس 2023 - كاملة',
        category: 'cars',
        categoryName: 'سيارات',
        price: 28000000,
        currency: 'YER',
        negotiable: false,
        location: 'تعز',
        city: 'تعز',
        images: [],
        status: 'active',
        viewsCount: 156,
        specifications: {
            brand: 'كيا',
            model: 'سيلتوس',
            year: 2023,
            color: 'أحمر',
            condition: 'new',
            kilometers: 0
        },
        trader: {
            id: 't3',
            name: 'عبدالله القحومي',
            phone: '773456789',
            isVerified: false,
            rating: 4.2,
            ratingCount: 18,
            city: 'تعز'
        }
    },
    {
        id: '4',
        title: 'فورد موستانج 2021 - V8',
        category: 'cars',
        categoryName: 'سيارات',
        price: 85000000,
        currency: 'YER',
        negotiable: true,
        location: 'صنعاء',
        city: 'صنعاء',
        images: [],
        status: 'active',
        viewsCount: 312,
        specifications: {
            brand: 'فورد',
            model: 'موستانج',
            year: 2021,
            color: 'أزرق',
            condition: 'used',
            kilometers: 28000
        },
        trader: {
            id: 't4',
            name: 'محمد الأصبحي',
            phone: '774567890',
            isVerified: true,
            rating: 4.9,
            ratingCount: 67,
            city: 'صنعاء'
        }
    },
    // Real Estate
    {
        id: '5',
        title: 'فيلا فاخرة في حي النهضة - 500م²',
        category: 'real-estate',
        categoryName: 'عقارات',
        price: 350000000,
        currency: 'YER',
        negotiable: true,
        location: 'صنعاء',
        city: 'صنعاء',
        images: [],
        status: 'active',
        viewsCount: 423,
        specifications: {
            type: 'فيلا',
            area: 500,
            bedrooms: 5,
            bathrooms: 4,
            floors: 3,
            furnishing: 'مفروشة'
        },
        trader: {
            id: 't5',
            name: 'شركة النور العقارية',
            phone: '775678901',
            isVerified: true,
            rating: 4.7,
            ratingCount: 89,
            city: 'صنعاء'
        }
    },
    {
        id: '6',
        title: 'شقة سكنية 3 غرف - حي الستين',
        category: 'real-estate',
        categoryName: 'عقارات',
        price: 85000000,
        currency: 'YER',
        negotiable: true,
        location: 'عدن',
        city: 'عدن',
        images: [],
        status: 'active',
        viewsCount: 287,
        specifications: {
            type: 'شقة',
            area: 180,
            bedrooms: 3,
            bathrooms: 2,
            floor: 5,
            furnishing: 'غير مفروشة'
        },
        trader: {
            id: 't6',
            name: 'إعمار العقارية',
            phone: '776789012',
            isVerified: true,
            rating: 4.4,
            ratingCount: 34,
            city: 'عدن'
        }
    },
    {
        id: '7',
        title: 'أرض صناعية - طريق华山',
        category: 'real-estate',
        categoryName: 'عقارات',
        price: 450000000,
        currency: 'YER',
        negotiable: false,
        location: 'صنعاء',
        city: 'صنعاء',
        images: [],
        status: 'active',
        viewsCount: 156,
        specifications: {
            type: 'أرض',
            area: 2000,
            usage: 'صناعية',
            status: 'صافية'
        },
        trader: {
            id: 't7',
            name: 'أحمد الزبيري',
            phone: '777890123',
            isVerified: false,
            rating: 4.0,
            ratingCount: 12,
            city: 'صنعاء'
        }
    },
    // Furniture
    {
        id: '8',
        title: 'طقم كنب ريفي جديد - 7 قطع',
        category: 'furniture',
        categoryName: 'أثاث',
        price: 3500000,
        currency: 'YER',
        negotiable: true,
        location: 'صنعاء',
        city: 'صنعاء',
        images: [],
        status: 'active',
        viewsCount: 234,
        specifications: {
            type: 'كنب',
            material: 'خشب زان',
            color: 'بني',
            pieces: 7,
            condition: 'new'
        },
        trader: {
            id: 't8',
            name: 'معرض الأثاث الحديث',
            phone: '778901234',
            isVerified: true,
            rating: 4.6,
            ratingCount: 56,
            city: 'صنعاء'
        }
    },
    {
        id: '9',
        title: 'غرفة نوم كاملة - سرير دولف',
        category: 'furniture',
        categoryName: 'أثاث',
        price: 5500000,
        currency: 'YER',
        negotiable: true,
        location: 'عدن',
        city: 'عدن',
        images: [],
        status: 'active',
        viewsCount: 178,
        specifications: {
            type: 'غرفة نوم',
            material: ' MDF',
            color: 'أبيض',
            includes: 'سرير، خزانة، طاولة',
            condition: 'new'
        },
        trader: {
            id: 't9',
            name: 'معرض الأثاث الذهبي',
            phone: '779012345',
            isVerified: false,
            rating: 4.1,
            ratingCount: 23,
            city: 'عدن'
        }
    },
    // Electronics
    {
        id: '10',
        title: 'ثلاجة سامسونج 32 قدم - جديدة',
        category: 'electronics',
        categoryName: 'أجهزة كهربائية',
        price: 1800000,
        currency: 'YER',
        negotiable: true,
        location: 'صنعاء',
        city: 'صنعاء',
        images: [],
        status: 'active',
        viewsCount: 312,
        specifications: {
            brand: 'سامسونج',
            type: 'ثلاجة',
            size: '32 قدم',
            color: 'فضي',
            warranty: 'سنة',
            condition: 'new'
        },
        trader: {
            id: 't10',
            name: 'إلكترونكس شوب',
            phone: '770123456',
            isVerified: true,
            rating: 4.8,
            ratingCount: 78,
            city: 'صنعاء'
        }
    },
    {
        id: '11',
        title: 'غسالة اتوماتيك 12 كجم - إل جي',
        category: 'electronics',
        categoryName: 'أجهزة كهربائية',
        price: 1500000,
        currency: 'YER',
        negotiable: false,
        location: 'تعز',
        city: 'تعز',
        images: [],
        status: 'active',
        viewsCount: 145,
        specifications: {
            brand: 'LG',
            type: 'غسالة',
            capacity: '12 كجم',
            color: 'أبيض',
            warranty: '6 أشهر',
            condition: 'used'
        },
        trader: {
            id: 't11',
            name: 'التقنية الحديثة',
            phone: '771234589',
            isVerified: false,
            rating: 3.9,
            ratingCount: 15,
            city: 'تعز'
        }
    },
    {
        id: '12',
        title: 'تلفزيون سمارت 55 بوصة - سوني',
        category: 'electronics',
        categoryName: 'أجهزة كهربائية',
        price: 4200000,
        currency: 'YER',
        negotiable: true,
        location: 'عدن',
        city: 'عدن',
        images: [],
        status: 'active',
        viewsCount: 267,
        specifications: {
            brand: 'سوني',
            type: 'تلفزيون',
            size: '55 بوصة',
            resolution: '4K',
            smart: true,
            condition: 'new'
        },
        trader: {
            id: 't12',
            name: 'السوق الإلكتروني',
            phone: '772345678',
            isVerified: true,
            rating: 4.5,
            ratingCount: 67,
            city: 'عدن'
        }
    },
    // Jobs
    {
        id: '13',
        title: 'مطلوب محاسب خبرة 3 سنوات - شركة النور',
        category: 'jobs',
        categoryName: 'وظائف',
        price: 500000,
        currency: 'YER',
        negotiable: false,
        location: 'صنعاء',
        city: 'صنعاء',
        images: [],
        status: 'active',
        viewsCount: 189,
        specifications: {
            jobType: 'دوام كامل',
            experience: '3 سنوات',
            education: 'بكالوريوس محاسبة',
            gender: 'ذكر/أنثى'
        },
        trader: {
            id: 't13',
            name: 'شركة النور',
            phone: '773456789',
            isVerified: true,
            rating: 4.3,
            ratingCount: 45,
            city: 'صنعاء'
        }
    },
    {
        id: '14',
        title: 'وظيفة مراقب جودة - مصنع textile',
        category: 'jobs',
        categoryName: 'وظائف',
        price: 400000,
        currency: 'YER',
        negotiable: false,
        location: 'تعز',
        city: 'تعز',
        images: [],
        status: 'active',
        viewsCount: 98,
        specifications: {
            jobType: 'دوام كامل',
            experience: 'سنة واحدة',
            education: 'ثانوية عامة',
            gender: 'ذكر'
        },
        trader: {
            id: 't14',
            name: 'مصنع التقدم',
            phone: '774567890',
            isVerified: false,
            rating: 3.8,
            ratingCount: 12,
            city: 'تعز'
        }
    }
];

// Global state
let currentAds = [];
let currentCategory = 'all';

// ============================================================
// Initialization
// ============================================================
document.addEventListener('DOMContentLoaded', function() {
    loadAds();
    setupFilters();
});

// ============================================================
// Load Ads
// ============================================================
function loadAds() {
    const loading = document.getElementById('loading');
    const adsGrid = document.getElementById('adsGrid');
    const emptyState = document.getElementById('emptyState');

    loading.style.display = 'flex';

    // Simulate API call delay
    setTimeout(() => {
        currentAds = sampleAds;
        renderAds(currentAds);
        loading.style.display = 'none';

        if (currentAds.length === 0) {
            emptyState.style.display = 'block';
            adsGrid.style.display = 'none';
        } else {
            emptyState.style.display = 'none';
            adsGrid.style.display = 'grid';
        }
    }, 500);
}

// ============================================================
// Render Ads
// ============================================================
function renderAds(ads) {
    const adsGrid = document.getElementById('adsGrid');
    adsGrid.innerHTML = '';

    ads.forEach(ad => {
        const adCard = createAdCard(ad);
        adsGrid.appendChild(adCard);
    });
}

// ============================================================
// Category Filter
// ============================================================
function filterByCategory(category) {
    currentCategory = category;

    // Update active category in UI
    document.querySelectorAll('.category-card').forEach(card => {
        card.classList.remove('active');
    });
    document.querySelector(`[data-category="${category}"]`).classList.add('active');

    // Update section title
    const sectionTitle = document.getElementById('sectionTitle');
    const icon = categoryIcons[category] || '🏪';
    const name = categoryNames[category] || 'الكل';
    sectionTitle.innerHTML = `
        <svg viewBox="0 0 24 24">
            <path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-5 14H7v-2h7v2zm3-4H7v-2h10v2zm0-4H7V7h10v2z"/>
        </svg>
        <span>${name}</span>
    `;

    // Filter ads
    let filtered = sampleAds;
    if (category !== 'all') {
        filtered = sampleAds.filter(ad => ad.category === category);
    }

    // Apply additional filters
    const searchTerm = document.getElementById('searchInput').value.toLowerCase();
    const city = document.getElementById('cityFilter').value;
    const priceRange = document.getElementById('priceFilter').value;

    filtered = filterAdsInternal(filtered, searchTerm, city, priceRange);

    currentAds = filtered;
    renderAds(filtered);

    // Update empty state visibility
    const emptyState = document.getElementById('emptyState');
    const adsGrid = document.getElementById('adsGrid');

    if (filtered.length === 0) {
        emptyState.style.display = 'block';
        adsGrid.style.display = 'none';
    } else {
        emptyState.style.display = 'none';
        adsGrid.style.display = 'grid';
    }
}

// ============================================================
// Create Ad Card
// ============================================================
function createAdCard(ad) {
    const card = document.createElement('div');
    card.className = 'ad-card';
    card.dataset.id = ad.id;
    card.dataset.category = ad.category;

    const priceFormatted = formatPrice(ad.price);
    const traderInitial = ad.trader.name.charAt(0);
    const categoryIcon = categoryIcons[ad.category] || '🏪';
    const conditionText = getConditionText(ad.specifications.condition);
    const typeText = getTypeText(ad);

    card.innerHTML = `
        <div class="ad-card-image">
            ${getCategoryIcon(ad.category)}
            <span class="ad-card-badge">${typeText}</span>
            ${ad.trader.isVerified ? `
                <span class="ad-card-verified">
                    <svg viewBox="0 0 24 24">
                        <path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/>
                    </svg>
                    موثق
                </span>
            ` : ''}
        </div>
        <div class="ad-card-content">
            <h3 class="ad-card-title">${ad.title}</h3>
            <div class="ad-card-meta">
                ${ad.specifications.year ? `<span>${ad.specifications.year}</span>` : ''}
                ${ad.specifications.area ? `<span>${ad.specifications.area}م²</span>` : ''}
                <span class="category-tag">${categoryIcon} ${ad.categoryName}</span>
            </div>
            <div class="ad-card-location">
                <svg viewBox="0 0 24 24">
                    <path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z"/>
                </svg>
                ${ad.location}
            </div>
            <div class="ad-card-price">
                ${priceFormatted}
                <small>${getCurrencyText(ad.currency)}</small>
                ${ad.negotiable ? '<span class="ad-card-negotiable">قابل للتفاوض</span>' : ''}
            </div>

            <div class="ad-card-trader">
                <div class="trader-avatar">${traderInitial}</div>
                <div class="trader-info">
                    <div class="trader-name">
                        ${ad.trader.name}
                        ${ad.trader.isVerified ? '<svg viewBox="0 0 24 24" width="14" height="14" fill="#4CAF50"><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/></svg>' : ''}
                    </div>
                    <div class="trader-rating">
                        <svg viewBox="0 0 24 24">
                            <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z"/>
                        </svg>
                        ${ad.trader.rating.toFixed(1)} (${ad.trader.ratingCount})
                    </div>
                </div>
            </div>

            <div class="ad-card-actions">
                <button class="action-btn action-btn-call" onclick="callTrader('${ad.trader.phone}')">
                    <svg viewBox="0 0 24 24">
                        <path d="M6.62 10.79c1.44 2.83 3.76 5.14 6.59 6.59l2.2-2.2c.27-.27.67-.36 1.02-.24 1.12.37 2.33.57 3.57.57.55 0 1 .45 1 1V20c0 .55-.45 1-1 1-9.39 0-17-7.61-17-17 0-.55.45-1 1-1h3.5c.55 0 1 .45 1 1 0 1.25.2 2.45.57 3.57.11.35.03.74-.25 1.02l-2.2 2.2z"/>
                    </svg>
                    اتصال
                </button>
                <button class="action-btn action-btn-whatsapp" onclick="openWhatsApp('${ad.trader.phone}', '${ad.title}')">
                    <svg viewBox="0 0 24 24">
                        <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.218 1.366.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
                    </svg>
                    واتساب
                </button>
            </div>
        </div>
    `;

    return card;
}

// ============================================================
// Get Category Icon SVG
// ============================================================
function getCategoryIcon(category) {
    const icons = {
        'cars': `<svg viewBox="0 0 24 24"><path d="M18.92 6.01C18.72 5.42 18.16 5 17.5 5h-11c-.66 0-1.21.42-1.42 1.01L3 12v8c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-1h12v1c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-8l-2.08-5.99zM6.5 16c-.83 0-1.5-.67-1.5-1.5S5.67 13 6.5 13s1.5.67 1.5 1.5S7.33 16 6.5 16zm11 0c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5.67 1.5 1.5-.67 1.5-1.5 1.5zM5 11l1.5-4.5h11L19 11H5z"/></svg>`,
        'real-estate': `<svg viewBox="0 0 24 24"><path d="M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z"/></svg>`,
        'furniture': `<svg viewBox="0 0 24 24"><path d="M21 9V7c0-1.65-1.35-3-3-3H6C4.35 4 3 5.35 3 7v2c-1.65 0-3 1.35-3 3v5c0 .55.45 1 1 1h3v2H2v2h20v-2h-2v-2h3c.55 0 1-.45 1-1v-5c0-1.65-1.35-3-3-3zM5 7c0-.55.45-1 1-1s1 .45 1 1v2c0 .55-.45 1-1 1s-1-.45-1-1V7zm14 0c0 .55-.45 1-1 1s-1-.45-1-1V7c0-.55.45-1 1-1s1 .45 1 1v2z"/></svg>`,
        'electronics': `<svg viewBox="0 0 24 24"><path d="M17 1.01L7 1c-1.1 0-2 .9-2 2v18c0 1.1.9 2 2 2h10c1.1 0 2-.9 2-2V3c0-1.1-.9-1.99-2-1.99zM17 19H7V5h10v14z"/></svg>`,
        'jobs': `<svg viewBox="0 0 24 24"><path d="M20 6h-4V4c0-1.11-.89-2-2-2h-4c-1.11 0-2 .89-2 2v2H4c-1.11 0-1.99.89-1.99 2L2 19c0 1.11.89 2 2 2h16c1.11 0 2-.89 2-2V8c0-1.11-.89-2-2-2zm-6 0h-4V4h4v2z"/></svg>`
    };
    return icons[category] || `<svg viewBox="0 0 24 24"><path d="M20 6h-8l-2-2H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2z"/></svg>`;
}

// ============================================================
// Get Type Text
// ============================================================
function getTypeText(ad) {
    if (ad.category === 'cars' && ad.specifications.condition) {
        return getConditionText(ad.specifications.condition);
    }
    if (ad.category === 'real-estate' && ad.specifications.type) {
        return ad.specifications.type;
    }
    if (ad.category === 'jobs' && ad.specifications.jobType) {
        return ad.specifications.jobType;
    }
    if (ad.specifications.condition === 'new') return 'جديد';
    if (ad.specifications.condition === 'used') return 'مستعمل';
    return ad.categoryName;
}

// ============================================================
// Filters
// ============================================================
function setupFilters() {
    const searchInput = document.getElementById('searchInput');
    const cityFilter = document.getElementById('cityFilter');
    const priceFilter = document.getElementById('priceFilter');

    searchInput.addEventListener('input', () => filterWithCurrentCategory());
    cityFilter.addEventListener('change', () => filterWithCurrentCategory());
    priceFilter.addEventListener('change', () => filterWithCurrentCategory());
}

function filterWithCurrentCategory() {
    const searchTerm = document.getElementById('searchInput').value.toLowerCase();
    const city = document.getElementById('cityFilter').value;
    const priceRange = document.getElementById('priceFilter').value;

    let filtered = sampleAds;
    if (currentCategory !== 'all') {
        filtered = sampleAds.filter(ad => ad.category === currentCategory);
    }

    filtered = filterAdsInternal(filtered, searchTerm, city, priceRange);
    currentAds = filtered;
    renderAds(filtered);

    const emptyState = document.getElementById('emptyState');
    const adsGrid = document.getElementById('adsGrid');

    if (filtered.length === 0) {
        emptyState.style.display = 'block';
        adsGrid.style.display = 'none';
    } else {
        emptyState.style.display = 'none';
        adsGrid.style.display = 'grid';
    }
}

function filterAdsInternal(ads, searchTerm, city, priceRange) {
    return ads.filter(ad => {
        // Search term
        if (searchTerm && !ad.title.toLowerCase().includes(searchTerm) &&
            !ad.categoryName.toLowerCase().includes(searchTerm) &&
            (ad.specifications.brand && !ad.specifications.brand.toLowerCase().includes(searchTerm)) &&
            (ad.specifications.type && !ad.specifications.type.toLowerCase().includes(searchTerm))) {
            return false;
        }

        // City
        if (city && ad.city !== city) {
            return false;
        }

        // Price range
        if (priceRange) {
            const parts = priceRange.split('-');
            const min = parseInt(parts[0]) || 0;
            const max = parts[1] ? parseInt(parts[1]) : Infinity;
            if (ad.price < min || ad.price > max) {
                return false;
            }
        }

        return true;
    });
}

// ============================================================
// Actions
// ============================================================
function callTrader(phone) {
    window.location.href = `tel:${phone}`;
}

function openWhatsApp(phone, carTitle) {
    // Format phone number for WhatsApp ( Yemen country code)
    const formattedPhone = phone.replace(/^0/, '967');
    const message = encodeURIComponent(`مرحباً، أنا مهتم بالإعلان: ${carTitle}`);
    window.open(`https://wa.me/${formattedPhone}?text=${message}`, '_blank');
}

function toggleMenu() {
    const headerActions = document.getElementById('headerActions');
    headerActions.classList.toggle('active');
}

// ============================================================
// Utilities
// ============================================================
function formatPrice(price) {
    return price.toLocaleString('ar-YE');
}

function getCurrencyText(currency) {
    const currencies = {
        'YER': 'ريال يمني',
        'USD': 'دولار أمريكي',
        'SAR': 'ريال سعودي'
    };
    return currencies[currency] || currency;
}

function getConditionText(condition) {
    const conditions = {
        'new': 'جديد',
        'used': 'مستعمل',
        'refurbished': 'مُجدَّد'
    };
    return conditions[condition] || condition;
}

function generateStars(rating, isDetailed = false) {
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 >= 0.5;
    const emptyStars = 5 - fullStars - (hasHalfStar ? 1 : 0);

    let html = '';
    for (let i = 0; i < fullStars; i++) {
        html += `<svg viewBox="0 0 24 24" class="${isDetailed ? 'filled' : ''}"><path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z"/></svg>`;
    }
    if (hasHalfStar) {
        html += `<svg viewBox="0 0 24 24" class="${isDetailed ? 'filled' : ''}"><path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2z"/></svg>`;
    }
    for (let i = 0; i < emptyStars; i++) {
        html += `<svg viewBox="0 0 24 24" class="empty"><path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z"/></svg>`;
    }
    return html;
}

// ============================================================
// Toast Notifications
// ============================================================
function showToast(message, type = 'success') {
    const existingToast = document.querySelector('.toast');
    if (existingToast) {
        existingToast.remove();
    }

    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.textContent = message;
    document.body.appendChild(toast);

    setTimeout(() => {
        toast.remove();
    }, 3000);
}